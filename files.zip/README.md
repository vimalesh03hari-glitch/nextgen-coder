# Recall

Turn your notes into active-recall practice instead of rereading them.

Paste or upload study material and Recall generates:

- **Flashcards** with recall-first flipping and self-rating
- **Quiz** questions with explanations
- **Fill the gaps** typing exercises (typo tolerant, with hints)
- **Match up** term and definition game against a timer
- **Explain it back** prompts with a key-point checklist and optional AI feedback
- **Smart review** that mixes items and prioritises what you know least

Progress is tracked per item and per topic using a simple five-level confidence scale. Missed items come back sooner.

It is a single static file (`index.html`) with no build step and no dependencies.

## Run it

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy on GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings, Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your app appears at `https://<your-username>.github.io/<repo-name>/`.

## Two ways to generate practice

| Mode | What you get | Setup |
| --- | --- | --- |
| **Offline** (default) | Cloze, flashcards, quiz and matching built on-device from headings, `Term: definition` lines and factual sentences. No data leaves your browser. | None |
| **Claude** | Higher-quality questions covering the whole material, AI feedback on your explanations, and transcription of photographed notes. | Paste an Anthropic API key in the **Connect Claude** panel |

### About the API key

- The key is stored in your browser's `localStorage` and sent only to `api.anthropic.com`.
- Calls are made directly from the browser using Anthropic's browser-access header, so usage is billed to your own account.
- Anyone with access to your browser profile can read the key. Do not use a key with a high spend limit on a shared computer, and never commit a key to the repo.
- For a public multi-user deployment, put the API behind your own small server instead of asking users for keys.

Models are set at the top of the Claude connection section in `index.html` (`MAIN_MODEL` and `QUICK_MODEL`).

## Supported input

Pasted text, and `.txt`, `.md`, `.csv`, `.json`, `.html` files. PDFs and Word files can not be read in the browser, so copy the text and paste it in. Photos of notes are transcribed when Claude is connected.

## Data and privacy

Sets and progress live in `localStorage` under `recall.sets.v1`. Clearing site data removes them. Nothing is sent anywhere unless you connect Claude.

## Ideas for next steps

- Date-based spaced repetition scheduling
- Export a set as a printable revision sheet or JSON
- PDF text extraction with a bundled PDF.js
- Import and export sets between devices

## Licence

MIT
